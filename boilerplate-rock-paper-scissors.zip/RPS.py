# markov chain, https://forum.freecodecamp.org/t/ml-with-python-rock-paper-scissors/461657/5

#

# The example function below keeps track of the opponent's history and plays whatever the opponent played two plays ago. It is not a very good player so you will need to change the code to pass the challenge.
import random
import numpy as np

def find_opponent(history):
  quincy = ['R', 'P', 'P', 'S', 'R']
  abbey = ['P', 'P', 'R', 'R', 'R']
  kris = ['P', 'R', 'R', 'R', 'R']
  mrugesh = ['R', 'R', 'R', 'R', 'R']
  if history == quincy:
    return 'qunicy'
  if history == abbey:
    return 'abbey'
  if history == kris:
    return 'kris'
  if history == mrugesh:
    return 'mrugesh'
  return 'error'

def player(prev_play, opponent_history=[], user_history=[], opponent=[None], play_order=[{
              "RR": 0,
              "RP": 0,
              "RS": 0,
              "PR": 0,
              "PP": 0,
              "PS": 0,
              "SR": 0,
              "SP": 0,
              "SS": 0,
          }]):
  opponent_history.append(prev_play)
  if len(opponent_history) < 6:
    user_history.append('S')
    return "S"
  else:
    choice = ""
    # decide on the player that is playing, and then store the player in "opponent"
    if opponent[0] is None:
      found_opponent = find_opponent(opponent_history[1:])
      if found_opponent == 'error':
        print("error of checking of opponent history to assign opponent")
        exit(9)
      opponent[0] = found_opponent
    if opponent[0] == 'qunicy':
      best_choices = ['P', 'P', 'S', 'S', 'R']
      choice = best_choices[len(opponent_history)%5]
    if opponent[0] == 'kris':
      # find out what the last user's move was
      prev_user_move = user_history[-1]
      if prev_user_move == 'P':
        choice = 'R'
      if prev_user_move == 'R':
        choice = 'S'
      if prev_user_move == 'S':
        choice = 'P'
    if opponent[0] == 'mrugesh':
      # use mrugesh's algorithm to find the choice that was taken the most over the past 10 plays, then outplay him
      if len(user_history) >= 10:
        last_ten = user_history[-10:]
        most_frequent = max(set(last_ten), key=last_ten.count)
        if most_frequent == 'P':
          choice = 'R'
        elif most_frequent == 'R':
          choice = 'S'
        elif most_frequent == 'S':
          choice = 'P'
        else:
          print('choice was not selected against mrugesh')
          exit(9)
      else:
        choice = random.choice(['R', 'P', 'S'])
    if opponent[0] == 'abbey':
      last_two = ''.join(user_history[-2:])
      play_order[0][last_two] += 1
      potential_plays = [
        user_history[-1] + "R",
        user_history[-1] + "P",
        user_history[-1] + "S",
      ]

      sub_order = {
          k: play_order[0][k]
          for k in potential_plays if k in play_order[0]
      }
              
      prediction = max(sub_order, key=sub_order.get)[-1]

      if prediction == 'P':
        choice = 'R'
      elif prediction == 'R':
        choice = 'S'
      elif prediction == 'S':
        choice = 'P'
      else:
        print('no choice was made against abbey')
        exit(9)
    
      
    if choice == '':
      print("no choice was made")
      exit(9)
    user_history.append(choice)
    # check if the arguments need to be reset
    if len(user_history) == 1000:
      user_history.clear()
      opponent_history.clear()
      opponent[0] = None
    return choice
  
'''
def get_index(choice):
  # returns an index for a 3x3 matrix for the corresponding input
  if choice == "R": return 0
  if choice == "P": return 1
  if choice == "S": return 2
  return -1

def get_choice(index):
  # returns the corresponding action (R, P, S) to take
  if index == 0: return "R"
  if index == 1: return "P"
  if index == 2: return "S"
  return ""

# try to make a Q table with 3x3? dimensions, to store the reward for picking various options
# the table might need to be bigger to account for user actions
# there are 9 different actions, as follows
# rock - paper, rock - rock, rock - scissors
# paper - rock, paper - paper, paper - scissors
# scissors - rock, scissors - paper, scissors - scissors

# function default parameters must be saved as lists to change the value
# and have it be the same across function calls

# the constants list is for the following: [epsilon, learning rate, discount factor]

# one problem is how to reset the default parameters for the next opponenets?
def player(prev_play, opponent_history=[], Q=[np.zeros((3, 3))], constants=[1, 0.001, 0.75], user_history=[], rewards=[0,0.5,1]):
  print(Q)
  # we need some type of q table so that we can pass it back
  # to the function and use it to track out our plays and our 
  # opponent's plays, because the opponenet's make moves based 
  # on what we did in the past
  
  # play random moves for the first couple moves?
  # set a percent you want to explore, for example 100% to start then
  # slowly decrement as time goes on

  # determine the result of the previous game after playing the previous move
  # 0 loss, 0.5 tie, and 1 win, we want to maximize the winning chances

  prev_opponent_choice = opponent_history[-1] if len(opponent_history) > 0 else "" # previous round bot choice
  prev_user_choice = user_history[-1] if len(user_history) > 0 else "" # previous round user choice

  if prev_opponent_choice != "" and prev_user_choice != "":
    # update the q-table based on the result of the previous game

    # determine a win, loss, or tie
    reward = -1
    if prev_opponent_choice == prev_user_choice:
      reward = rewards[1] # reward for tie
    elif prev_opponent_choice == "R" and prev_user_choice == "S":
      reward = rewards[0] # reward for loss
    elif prev_opponent_choice == "P" and prev_user_choice == "R":
      reward = rewards[0] # reward for loss
    elif prev_opponent_choice == "S" and prev_user_choice == "P":
      reward = rewards[0] # reward for loss
    else:
      reward = rewards[2] # all options are exhausted for losing, so player won
    # then, change the value in the Q-table
    next_state = "R" # the best action from the previous opponent's move
    if prev_opponent_choice == "R": # best action against rock is paper
      next_state = "P" 
    elif prev_opponent_choice == "P": # best action against paper is scissors
      next_state = "S"
    next_state = get_index(next_state)

    # convert choices ["R", "P", "S"] to indicies in the matrix, bot=row, user=column
    oppo = get_index(prev_opponent_choice)
    user = get_index(prev_user_choice)
6
    Q[0][oppo, user] = Q[0][oppo, user] + constants[1] * (reward + constants[2] * max(Q[0][next_state]) - Q[0][oppo, user]) 
    
    # decrease the discount rate? since an action has been changed in the Q-table
    #constants[2]-=0.01
  
  opponent_history.append(prev_play)
  
  if random.uniform(0, 1) <= constants[0]: #epsilon
    constants[0]-=0.005 # minimize the randomization chance
    choice = random.choice(['R', 'P', 'S'])
    user_history.append(choice)
    return choice
  else:
    # determine the best value from the Q-table based on opponent's move
    q_list = list(Q[0][get_index(prev_opponent_choice)])
    return get_choice(q_list.index(max(q_list)))


#formulas and meanings
# Q (s, a) = Q (s, a) + l × (r + γ + max Q (ns, a) – Q (s, a)): s and a state and action
# l = learning rate
# γ = discount rate
# r = reward
# ns = next state, decided by the action decided by the AI, which will dictate the next action that the AI will take

# current problems
# Q-table is init to zero every function call (resolved)
# can't beat quincy (the easy one)
# the q-table update is wrong, need perhaps different dimensions'''